import { RoleGate } from '@/components/RoleGate'
import { createClient } from '@/lib/supabase/server'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { LogOut, FileText, CheckCircle2, Clock, AlertCircle, Home, User, Plus, Users, Menu, BookOpen } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'
import { redirect } from 'next/navigation'
import { formatDistanceToNow } from 'date-fns'
import { MobileNav } from '@/components/MobileNav'

async function getTeacherAssignments(teacherId: string) {
  const supabase = await createClient()
  
  const { data } = await supabase
    .from('assignments')
    .select(`
      *,
      class:classes(
        id,
        name,
        branch:branches(
          id,
          name
        )
      ),
      submissions(id, grade, submitted_at)
    `)
    .eq('teacher_id', teacherId)
    .order('created_at', { ascending: false })
  
  return data || []
}

async function handleLogout() {
  'use server'
  const supabase = await createClient()
  await supabase.auth.signOut()
  redirect('/login')
}

export default async function TeacherDashboard() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) redirect('/login')
  
  const { data: profile } = await supabase
    .from('profiles')
    .select('full_name')
    .eq('id', user.id)
    .single()
  
  const assignments = await getTeacherAssignments(user.id)
  
  const totalAssignments = assignments.length
  const totalSubmissions = assignments.reduce((acc: number, a: any) => acc + (a.submissions?.length || 0), 0)
  const graded = assignments.reduce((acc: number, a: any) => 
    acc + (a.submissions?.filter((s: any) => s.grade).length || 0), 0)
  const pending = totalSubmissions - graded
  
  return (
    <RoleGate allowedRole="teacher">
      <div className="flex h-screen bg-gray-50">
        {/* Mobile Navigation */}
        <MobileNav 
          role="teacher" 
          userName={profile?.full_name}
          onLogout={async () => {
            'use server'
            await handleLogout()
          }}
        />
        
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex w-64 bg-white border-r border-gray-200 flex-col">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-2">
              <Image
                src="/logo.png"
                width={80}
                height={80}
                alt="Logo"
                className="rounded-2xl"
              />
              <span className="font-bold text-xl">AssignMate</span>
            </div>
          </div>
          
          <nav className="flex-1 p-4">
            <div className="space-y-1">
              <Link href="/teacher" className="flex items-center gap-3 px-3 py-2 rounded-lg bg-gray-100 text-gray-900">
                <Home className="h-5 w-5" />
                <span className="font-medium">Overview</span>
              </Link>
            </div>
          </nav>
          
          <div className="p-4 border-t border-gray-200">
            <form action={handleLogout}>
              <Button variant="ghost" type="submit" className="w-full justify-start">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </form>
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden lg:pt-0 pt-14">
          {/* Top Navigation */}
          <header className="hidden lg:block bg-white border-b border-gray-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-xl font-semibold">Dashboard / <span className="text-gray-500">Overview</span></h1>
              </div>
              <div className="flex items-center gap-4">
                <Link href="/teacher/assignments/new">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    <span className="hidden sm:inline">New Assignment</span>
                    <span className="sm:hidden">New</span>
                  </Button>
                </Link>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <User className="h-4 w-4" />
                  <span>{profile?.full_name}</span>
                </div>
              </div>
            </div>
          </header>

          {/* Main Content Area */}
          <main className="flex-1 overflow-y-auto p-4 sm:p-6">
            <div className="max-w-7xl mx-auto space-y-4 sm:space-y-6">
              {/* Mobile Header with Action Button */}
              <div className="lg:hidden flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-xl font-bold">Overview</h2>
                </div>
                <Link href="/teacher/assignments/new">
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
              
              {/* Desktop Header */}
              <div className="hidden lg:flex items-center justify-between">
                <div>
                  <h2 className="text-xl sm:text-2xl font-bold">Dashboard Overview</h2>
                  <p className="text-sm sm:text-base text-gray-600 mt-1">Monitor your assignments and student submissions</p>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Link href="/teacher/assignments/new" className="no-underline">
                  <div className="h-full">
                    <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                      <CardHeader className="flex flex-row items-center space-y-0 p-4 sm:pb-2">
                        <div className="w-10 sm:w-12 h-10 sm:h-12 rounded-lg bg-green-100 flex items-center justify-center mr-3 sm:mr-4 flex-shrink-0">
                          <Plus className="h-5 sm:h-6 w-5 sm:w-6 text-green-600" />
                        </div>
                        <div className="min-w-0">
                          <CardTitle className="text-sm sm:text-base font-medium">New assignment</CardTitle>
                          <CardDescription className="text-xs sm:text-sm">Create a new assignment</CardDescription>
                        </div>
                      </CardHeader>
                    </Card>
                  </div>
                </Link>

                <Link href="/teacher/assignments" className="no-underline">
                  <div className="h-full">
                    <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                      <CardHeader className="flex flex-row items-center space-y-0 p-4 sm:pb-2">
                        <div className="w-10 sm:w-12 h-10 sm:h-12 rounded-lg bg-red-100 flex items-center justify-center mr-3 sm:mr-4 flex-shrink-0">
                          <AlertCircle className="h-5 sm:h-6 w-5 sm:w-6 text-red-600" />
                        </div>
                        <div className="min-w-0">
                          <CardTitle className="text-sm sm:text-base font-medium">View submissions</CardTitle>
                          <CardDescription className="text-xs sm:text-sm">Check student work</CardDescription>
                        </div>
                      </CardHeader>
                    </Card>
                  </div>
                </Link>

                <Link href="/teacher/assignments" className="no-underline">
                  <div className="h-full">
                    <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                      <CardHeader className="flex flex-row items-center space-y-0 p-4 sm:pb-2">
                        <div className="w-10 sm:w-12 h-10 sm:h-12 rounded-lg bg-blue-100 flex items-center justify-center mr-3 sm:mr-4 flex-shrink-0">
                          <CheckCircle2 className="h-5 sm:h-6 w-5 sm:w-6 text-blue-600" />
                        </div>
                        <div className="min-w-0">
                          <CardTitle className="text-sm sm:text-base font-medium">Grade work</CardTitle>
                          <CardDescription className="text-xs sm:text-sm">Review and grade</CardDescription>
                        </div>
                      </CardHeader>
                    </Card>
                  </div>
                </Link>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between p-3 sm:p-4 pb-2">
                    <div className="w-8 sm:w-10 h-8 sm:h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                      <FileText className="h-4 sm:h-5 w-4 sm:w-5 text-gray-600" />
                    </div>
                    <span className="text-xs sm:text-sm text-green-600 font-medium">Active</span>
                  </CardHeader>
                  <CardContent className="p-3 sm:p-4 pt-0">
                    <div className="text-2xl sm:text-3xl font-bold">{totalAssignments}</div>
                    <p className="text-xs sm:text-sm text-gray-600 mt-1">Total Assignments</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between p-3 sm:p-4 pb-2">
                    <div className="w-8 sm:w-10 h-8 sm:h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                      <CheckCircle2 className="h-4 sm:h-5 w-4 sm:w-5 text-gray-600" />
                    </div>
                    <span className="text-xs sm:text-sm text-green-600 font-medium">+{totalSubmissions > 0 ? Math.round((graded/totalSubmissions)*100) : 0}%</span>
                  </CardHeader>
                  <CardContent className="p-3 sm:p-4 pt-0">
                    <div className="text-2xl sm:text-3xl font-bold">{totalSubmissions}</div>
                    <p className="text-xs sm:text-sm text-gray-600 mt-1">Total Submissions</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between p-3 sm:p-4 pb-2">
                    <div className="w-8 sm:w-10 h-8 sm:h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                      <Clock className="h-4 sm:h-5 w-4 sm:w-5 text-gray-600" />
                    </div>
                    <span className="text-xs sm:text-sm text-amber-600 font-medium">{pending}</span>
                  </CardHeader>
                  <CardContent className="p-3 sm:p-4 pt-0">
                    <div className="text-2xl sm:text-3xl font-bold">{pending}</div>
                    <p className="text-xs sm:text-sm text-gray-600 mt-1">Pending Grading</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between p-3 sm:p-4 pb-2">
                    <div className="w-8 sm:w-10 h-8 sm:h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                      <Users className="h-4 sm:h-5 w-4 sm:w-5 text-gray-600" />
                    </div>
                    <span className="text-xs sm:text-sm text-blue-600 font-medium">Active</span>
                  </CardHeader>
                  <CardContent className="p-3 sm:p-4 pt-0">
                    <div className="text-2xl sm:text-3xl font-bold">{graded}</div>
                    <p className="text-xs sm:text-sm text-gray-600 mt-1">Graded</p>
                  </CardContent>
                </Card>
              </div>

              {/* Assignments List */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Assignments</CardTitle>
                  <CardDescription>Your latest assignments and submission status</CardDescription>
                </CardHeader>
                <CardContent>
                  {assignments.length === 0 ? (
                    <div className="text-center py-12">
                      <BookOpen className="h-12 w-12 mx-auto text-gray-400 mb-3" />
                      <p className="text-gray-600">No assignments yet</p>
                      <p className="text-sm text-gray-500 mt-1">Create your first assignment to get started</p>
                      <Link href="/teacher/assignments/new">
                        <Button className="mt-4">
                          <Plus className="h-4 w-4 mr-2" />
                          Create Assignment
                        </Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {assignments.slice(0, 5).map((assignment: any) => {
                        const submissionCount = assignment.submissions?.length || 0
                        const gradedCount = assignment.submissions?.filter((s: any) => s.grade).length || 0
                        const dueDate = new Date(assignment.due_at)
                        
                        return (
                          <Link key={assignment.id} href={`/teacher/assignments/${assignment.id}`}>
                            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 sm:p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                              <div className="flex items-start sm:items-center gap-3 sm:gap-4 mb-3 sm:mb-0">
                                <div className="w-8 sm:w-10 h-8 sm:h-10 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                                  <FileText className="h-4 sm:h-5 w-4 sm:w-5 text-blue-600" />
                                </div>
                                <div className="min-w-0 flex-1">
                                  <h4 className="font-medium text-sm sm:text-base truncate">{assignment.title}</h4>
                                  <p className="text-xs sm:text-sm text-gray-600">
                                    {assignment.class.branch.name} - {assignment.class.name}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center justify-between sm:justify-end gap-3 sm:gap-4">
                                <div className="text-left sm:text-right">
                                  <p className="text-xs sm:text-sm font-medium">
                                    {submissionCount} {submissionCount === 1 ? 'Submission' : 'Submissions'}
                                  </p>
                                  <p className="text-xs text-gray-500">
                                    {gradedCount} graded • Due {formatDistanceToNow(dueDate, { addSuffix: true })}
                                  </p>
                                </div>
                                <div className="px-2 py-1 rounded text-xs font-medium bg-blue-100 text-blue-700">
                                  {submissionCount > 0 ? 'Active' : 'No Submissions'}
                                </div>
                              </div>
                            </div>
                          </Link>
                        )
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </main>
        </div>
      </div>
    </RoleGate>
  )
}
