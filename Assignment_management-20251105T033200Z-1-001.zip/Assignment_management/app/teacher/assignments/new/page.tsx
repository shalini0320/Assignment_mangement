'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { BranchClassPicker } from '@/components/BranchClassPicker'
import { AssignmentFileUpload } from '@/components/AssignmentFileUpload'
import { createClient } from '@/lib/supabase/client'

interface FilePreview {
  file: File
  id: string
}

export default function CreateAssignmentPage() {
  const router = useRouter()
  const [branchId, setBranchId] = useState('')
  const [classId, setClassId] = useState('')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [dueDate, setDueDate] = useState('')
  const [dueTime, setDueTime] = useState('')
  const [files, setFiles] = useState<FilePreview[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!classId || !title || !dueDate || !dueTime) {
      setError('Please fill in all required fields')
      return
    }

    const dueAt = new Date(`${dueDate}T${dueTime}`)
    if (dueAt < new Date()) {
      setError('Due date must be in the future')
      return
    }

    setLoading(true)

    try {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()

      if (!user) throw new Error('Not authenticated')

      const { data: assignmentData, error: insertError } = await supabase.from('assignments').insert({
        class_id: classId,
        teacher_id: user.id,
        title,
        description,
        due_at: dueAt.toISOString(),
      }).select()

      if (insertError) throw insertError

      const assignmentId = assignmentData?.[0]?.id
      if (!assignmentId) throw new Error('Failed to get assignment ID')

      // Upload files if any
      if (files.length > 0) {
        for (const filePreview of files) {
          const file = filePreview.file
          const fileName = `${Date.now()}-${file.name}`
          const filePath = `assignments/${assignmentId}/${fileName}`

          const { error: uploadError } = await supabase.storage
            .from('assignments')
            .upload(filePath, file)

          if (uploadError) throw uploadError

          const { error: dbError } = await supabase
            .from('assignment_files')
            .insert({
              assignment_id: assignmentId,
              file_path: filePath,
              file_name: file.name,
              file_type: file.type,
              file_size: file.size,
              uploaded_by: user.id,
            })

          if (dbError) throw dbError
        }
      }

      router.push('/teacher')
      router.refresh()
    } catch (err: any) {
      setError(err.message || 'Failed to create assignment')
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-3xl mx-auto px-4 py-3 sm:py-4">
          <Link href="/teacher">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Back to Dashboard</span>
              <span className="sm:hidden">Back</span>
            </Button>
          </Link>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-4 sm:py-8">
        <Card>
          <CardHeader className="p-4 sm:p-6">
            <CardTitle className="text-lg sm:text-xl">Create New Assignment</CardTitle>
          </CardHeader>
          <CardContent className="p-4 sm:p-6">
            <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
              <BranchClassPicker
                branchId={branchId}
                classId={classId}
                onBranchChange={setBranchId}
                onClassChange={setClassId}
              />

              <div>
                <Label htmlFor="title">Assignment Title *</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter assignment title"
                  className="mt-1"
                  disabled={loading}
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Enter assignment description (optional)"
                  className="mt-1"
                  rows={4}
                  disabled={loading}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="dueDate" className="text-sm">Due Date *</Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="mt-1"
                    disabled={loading}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="dueTime" className="text-sm">Due Time *</Label>
                  <Input
                    id="dueTime"
                    type="time"
                    value={dueTime}
                    onChange={(e) => setDueTime(e.target.value)}
                    className="mt-1"
                    disabled={loading}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="files">Assignment Files (Optional)</Label>
                <div className="mt-1">
                  <AssignmentFileUpload
                    onFilesReady={setFiles}
                  />
                </div>
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <p className="text-red-600 text-sm">{error}</p>
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-3">
                <Button type="submit" disabled={loading} className="flex-1 w-full">
                  {loading ? 'Creating...' : 'Create Assignment'}
                </Button>
                <Link href="/teacher" className="flex-1 w-full">
                  <Button type="button" variant="outline" className="w-full" disabled={loading}>
                    Cancel
                  </Button>
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
