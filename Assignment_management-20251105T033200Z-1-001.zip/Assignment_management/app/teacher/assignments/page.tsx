import { RoleGate } from '@/components/RoleGate'
import { createClient } from '@/lib/supabase/server'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { FileText, CheckCircle2 } from 'lucide-react'
import Link from 'next/link'
import { redirect } from 'next/navigation'
import { formatDistanceToNow } from 'date-fns'

async function getTeacherAssignments(teacherId: string) {
  const supabase = await createClient()
  const { data } = await supabase
    .from('assignments')
    .select(`
      *,
      class:classes(
        id,
        name,
        branch:branches(name)
      ),
      submissions(id, grade, submitted_at)
    `)
    .eq('teacher_id', teacherId)
    .order('created_at', { ascending: false })
  return data || []
}

export default async function TeacherAssignmentsIndex() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const assignments = await getTeacherAssignments(user.id)

  return (
    <RoleGate allowedRole="teacher">
      <div className="min-h-screen bg-gray-50">
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold">Assignments</h1>
              <p className="text-sm text-gray-600">View submissions and grade student work</p>
            </div>
            <Link href="/teacher/assignments/new">
              <Button>New Assignment</Button>
            </Link>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Your Assignments</CardTitle>
              <CardDescription>Click an assignment to view submissions and grade</CardDescription>
            </CardHeader>
            <CardContent>
              {assignments.length === 0 ? (
                <p className="text-center text-gray-600 py-10">No assignments yet</p>
              ) : (
                <div className="space-y-3">
                  {assignments.map((a: any) => {
                    const submissionCount = a.submissions?.length || 0
                    const gradedCount = a.submissions?.filter((s: any) => s.grade).length || 0
                    const dueDate = new Date(a.due_at)
                    return (
                      <Link key={a.id} href={`/teacher/assignments/${a.id}`}>
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 sm:p-4 border rounded-lg bg-white hover:bg-gray-50 transition-colors">
                          <div className="flex items-start sm:items-center gap-3 sm:gap-4">
                            <div className="w-8 sm:w-10 h-8 sm:h-10 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                              <FileText className="h-4 sm:h-5 w-4 sm:w-5 text-blue-600" />
                            </div>
                            <div className="min-w-0">
                              <h4 className="font-medium text-sm sm:text-base truncate">{a.title}</h4>
                              <p className="text-xs sm:text-sm text-gray-600 truncate">{a.class?.branch?.name} - {a.class?.name}</p>
                            </div>
                          </div>
                          <div className="flex items-center justify-between sm:justify-end gap-3 sm:gap-6 mt-3 sm:mt-0">
                            <div className="text-left sm:text-right text-xs sm:text-sm">
                              <p>{submissionCount} submissions • {gradedCount} graded</p>
                              <p className="text-gray-500">Due {formatDistanceToNow(dueDate, { addSuffix: true })}</p>
                            </div>
                            <div className="px-2 sm:px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700 flex items-center gap-1">
                              <CheckCircle2 className="h-3 w-3" />
                              Manage
                            </div>
                          </div>
                        </div>
                      </Link>
                    )
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </RoleGate>
  )
}
