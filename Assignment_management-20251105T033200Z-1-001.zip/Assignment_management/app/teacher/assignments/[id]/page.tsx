'use client'

import { useEffect, useState } from 'react'
import { use } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Download, Save } from 'lucide-react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'
import { format } from 'date-fns'

interface Submission {
  id: string
  student_id: string
  file_path: string
  submitted_at: string
  grade: string | null
  feedback: string | null
  student: {
    full_name: string
  }
}

interface Assignment {
  id: string
  title: string
  description: string
  due_at: string
  class: {
    name: string
    branch: {
      name: string
    }
  }
}

export default function TeacherAssignmentDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const [assignment, setAssignment] = useState<Assignment | null>(null)
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [grades, setGrades] = useState<Record<string, string>>({})
  const [feedbacks, setFeedbacks] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchData()
  }, [id])

  const fetchData = async () => {
    const supabase = createClient()
    
    const { data: assignmentData } = await supabase
      .from('assignments')
      .select(`
        *,
        class:classes(
          name,
          branch:branches(name)
        )
      `)
      .eq('id', id)
      .single()
    
    setAssignment(assignmentData)

    const { data: submissionsData } = await supabase
      .from('submissions')
      .select(`
        *,
        student:profiles!submissions_student_id_fkey(full_name)
      `)
      .eq('assignment_id', id)
      .order('submitted_at', { ascending: false })

    if (submissionsData) {
      setSubmissions(submissionsData as any)
      
      const gradesMap: Record<string, string> = {}
      const feedbacksMap: Record<string, string> = {}
      submissionsData.forEach((sub: any) => {
        gradesMap[sub.id] = sub.grade || ''
        feedbacksMap[sub.id] = sub.feedback || ''
      })
      setGrades(gradesMap)
      setFeedbacks(feedbacksMap)
    }
    
    setLoading(false)
  }

  const handleSave = async (submissionId: string) => {
    setSaving(submissionId)

    try {
      const supabase = createClient()
      const { error } = await supabase
        .from('submissions')
        .update({
          grade: grades[submissionId] || null,
          feedback: feedbacks[submissionId] || null,
        })
        .eq('id', submissionId)

      if (error) throw error

      await fetchData()
    } catch (err) {
      console.error('Failed to save grade:', err)
    } finally {
      setSaving(null)
    }
  }

  const handleDownload = async (filePath: string) => {
    const supabase = createClient()
    const { data } = await supabase.storage.from('submissions').createSignedUrl(filePath, 60)
    if (data?.signedUrl) {
      window.open(data.signedUrl, '_blank')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p>Loading...</p>
      </div>
    )
  }

  if (!assignment) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p>Assignment not found</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/teacher">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">{assignment.title}</CardTitle>
            <p className="text-sm text-gray-600">
              {assignment.class.branch.name} - {assignment.class.name}
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {assignment.description && (
                <p className="text-gray-700">{assignment.description}</p>
              )}
              <p className="text-sm text-gray-600">
                Due: {format(new Date(assignment.due_at), 'PPP p')}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Submissions ({submissions.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {submissions.length === 0 ? (
              <p className="text-center text-gray-600 py-8">No submissions yet</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student</TableHead>
                      <TableHead>Submitted</TableHead>
                      <TableHead>File</TableHead>
                      <TableHead>Grade</TableHead>
                      <TableHead>Feedback</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {submissions.map((submission) => (
                      <TableRow key={submission.id}>
                        <TableCell className="font-medium">
                          {submission.student.full_name}
                        </TableCell>
                        <TableCell className="text-sm text-gray-600">
                          {format(new Date(submission.submitted_at), 'PPP p')}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDownload(submission.file_path)}
                          >
                            <Download className="h-3 w-3 mr-1" />
                            Download
                          </Button>
                        </TableCell>
                        <TableCell>
                          <Input
                            value={grades[submission.id]}
                            onChange={(e) =>
                              setGrades({ ...grades, [submission.id]: e.target.value })
                            }
                            placeholder="Grade"
                            className="w-24"
                          />
                        </TableCell>
                        <TableCell>
                          <Textarea
                            value={feedbacks[submission.id]}
                            onChange={(e) =>
                              setFeedbacks({ ...feedbacks, [submission.id]: e.target.value })
                            }
                            placeholder="Feedback"
                            rows={2}
                            className="min-w-[200px]"
                          />
                        </TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            onClick={() => handleSave(submission.id)}
                            disabled={saving === submission.id}
                          >
                            <Save className="h-3 w-3 mr-1" />
                            {saving === submission.id ? 'Saving...' : 'Save'}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
