import { RoleGate } from '@/components/RoleGate'
import { createClient } from '@/lib/supabase/server'
import { FileUploadWrapper } from '@/components/FileUploadWrapper'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Calendar, Download, FileText } from 'lucide-react'
import Link from 'next/link'
import { redirect } from 'next/navigation'
import { format } from 'date-fns'
import { use } from 'react'

async function getAssignmentDetails(assignmentId: string, studentId: string) {
  const supabase = await createClient()
  
  const { data: assignment } = await supabase
    .from('assignments')
    .select(`
      *,
      class:classes(
        name,
        branch:branches(name)
      )
    `)
    .eq('id', assignmentId)
    .single()
  
  if (!assignment) return null
  
  const { data: submissions } = await supabase
    .from('submissions')
    .select('*')
    .eq('assignment_id', assignmentId)
    .eq('student_id', studentId)
  
  const { data: assignmentFiles } = await supabase
    .from('assignment_files')
    .select('*')
    .eq('assignment_id', assignmentId)
  
  return { ...assignment, submissions: submissions || [], assignmentFiles: assignmentFiles || [] }
}

async function downloadFile(filePath: string) {
  'use server'
  const supabase = await createClient()
  const { data } = await supabase.storage.from('submissions').createSignedUrl(filePath, 60)
  return data?.signedUrl || ''
}

async function downloadAssignmentFile(filePath: string) {
  'use server'
  const supabase = await createClient()
  const { data } = await supabase.storage.from('assignments').createSignedUrl(filePath, 60)
  return data?.signedUrl || ''
}

export default async function AssignmentDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) redirect('/login')
  
  const assignment = await getAssignmentDetails(id, user.id)
  
  if (!assignment) {
    return <div>Assignment not found</div>
  }
  
  const submission = assignment.submissions?.[0]
  const dueDate = new Date(assignment.due_at)
  const isOverdue = dueDate < new Date()
  
  return (
    <RoleGate allowedRole="student">
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white border-b border-gray-200">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <Link href="/student">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="mb-6">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-2xl mb-2">{assignment.title}</CardTitle>
                  <p className="text-sm text-gray-600">
                    {assignment.class.branch.name} - {assignment.class.name}
                  </p>
                </div>
                {submission?.grade && (
                  <Badge className="bg-green-500">Graded: {submission.grade}</Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <div className="flex items-center text-sm text-gray-600 mb-3">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span className={isOverdue ? 'text-red-500' : ''}>
                    Due: {format(dueDate, 'PPP p')}
                    {isOverdue && ' (Overdue)'}
                  </span>
                </div>
                {assignment.description && (
                  <div className="prose max-w-none">
                    <p className="text-gray-700">{assignment.description}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {assignment.assignmentFiles && assignment.assignmentFiles.length > 0 && (
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-lg">Assignment Files</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {assignment.assignmentFiles.map((file: any) => (
                    <div key={file.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 mr-3 text-blue-500" />
                        <div>
                          <p className="font-medium text-sm">{file.file_name}</p>
                          <p className="text-xs text-gray-500">
                            {(file.file_size / 1024 / 1024).toFixed(2)} MB
                          </p>
                        </div>
                      </div>
                      <form action={async () => {
                        'use server'
                        const url = await downloadAssignmentFile(file.file_path)
                        redirect(url)
                      }}>
                        <Button variant="outline" size="sm" type="submit">
                          <Download className="h-4 w-4 mr-2" />
                          Download
                        </Button>
                      </form>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {submission ? (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Your Submission</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <FileText className="h-5 w-5 mr-3 text-blue-500" />
                      <div>
                        <p className="font-medium">Submitted file</p>
                        <p className="text-sm text-gray-600">
                          {format(new Date(submission.submitted_at), 'PPP p')}
                        </p>
                      </div>
                    </div>
                    <form action={async () => {
                      'use server'
                      const url = await downloadFile(submission.file_path)
                      redirect(url)
                    }}>
                      <Button variant="outline" size="sm" type="submit">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </form>
                  </div>

                  {submission.grade && (
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <h4 className="font-semibold text-green-900 mb-2">Grade: {submission.grade}</h4>
                      {submission.feedback && (
                        <div>
                          <p className="text-sm font-medium text-green-900 mb-1">Feedback:</p>
                          <p className="text-sm text-green-800">{submission.feedback}</p>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="border-t pt-4">
                    <h4 className="font-semibold mb-3">Replace Submission</h4>
                    <FileUploadWrapper
                      assignmentId={assignment.id}
                      studentId={user.id}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Submit Assignment</CardTitle>
              </CardHeader>
              <CardContent>
                <FileUploadWrapper
                  assignmentId={assignment.id}
                  studentId={user.id}
                />
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </RoleGate>
  )
}
