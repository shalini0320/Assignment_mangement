'use client'

import { useState, useEffect, Suspense } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { LogOut, BookOpen, FileText, CheckCircle2, Clock, AlertCircle, Home, User, RefreshCw, Menu } from 'lucide-react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { BranchClassPicker } from '@/components/BranchClassPicker'
import { formatDistanceToNow } from 'date-fns'
import { MobileNav } from '@/components/MobileNav'

function getStatusColor(status: string) {
  switch (status) {
    case 'pending':
      return 'bg-amber-100 text-amber-700'
    case 'submitted':
      return 'bg-blue-100 text-blue-700'
    case 'graded':
      return 'bg-green-100 text-green-700'
    case 'overdue':
      return 'bg-red-100 text-red-700'
    default:
      return 'bg-gray-100 text-gray-700'
  }
}

function getStatusIcon(status: string) {
  switch (status) {
    case 'pending':
      return <Clock className="h-5 w-5 text-amber-600" />
    case 'submitted':
      return <FileText className="h-5 w-5 text-blue-600" />
    case 'graded':
      return <CheckCircle2 className="h-5 w-5 text-green-600" />
    case 'overdue':
      return <AlertCircle className="h-5 w-5 text-red-600" />
    default:
      return <AlertCircle className="h-5 w-5 text-gray-600" />
  }
}

function AssignmentsPageInner() {
  const searchParams = useSearchParams()
  const filterParam = searchParams.get('filter')

  const [activeTab, setActiveTab] = useState('all')
  const [selectedBranch, setSelectedBranch] = useState('')
  const [selectedClass, setSelectedClass] = useState('')
  const [assignments, setAssignments] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [user, setUser] = useState<any>(null)

  // Initialize activeTab from URL
  useEffect(() => {
    if (filterParam === 'all' || filterParam === 'pending' || filterParam === 'submitted' || filterParam === 'graded') {
      setActiveTab(filterParam)
    }
  }, [filterParam])

  // Get current user
  useEffect(() => {
    const getUser = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      setUser(user)
    }
    getUser()
  }, [])

  // Fetch assignments when class/user changes
  useEffect(() => {
    if (!selectedClass || !user) {
      setAssignments([])
      return
    }
    const fetchAssignments = async () => {
      setLoading(true)
      const supabase = createClient()
      try {
        const { data } = await supabase
          .from('assignments')
          .select(`
            *,
            class:classes(
              name,
              branch:branches(name)
            ),
            submissions(id, grade, feedback, submitted_at)
          `)
          .eq('class_id', selectedClass)
          .eq('submissions.student_id', user.id)
          .order('due_at', { ascending: true })
        setAssignments(data || [])
      } catch (e) {
        console.error('Error fetching assignments:', e)
        setAssignments([])
      } finally {
        setLoading(false)
      }
    }
    fetchAssignments()
  }, [selectedClass, user])

  const getAssignmentStatus = (assignment: any) => {
    const hasSubmission = assignment.submissions?.length > 0
    const isGraded = assignment.submissions?.[0]?.grade
    const dueDate = new Date(assignment.due_at)
    const isOverdue = dueDate < new Date() && !hasSubmission

    if (isGraded) return 'graded'
    if (hasSubmission) return 'submitted'
    if (isOverdue) return 'overdue'
    return 'pending'
  }

  const filteredAssignments = assignments.filter((a) => {
    const status = getAssignmentStatus(a)
    if (activeTab === 'pending') return status === 'pending' || status === 'overdue'
    if (activeTab === 'submitted') return status === 'submitted'
    if (activeTab === 'graded') return status === 'graded'
    return true
  })

  const stats = {
    total: assignments.length,
    pending: assignments.filter((a) => {
      const s = getAssignmentStatus(a)
      return s === 'pending' || s === 'overdue'
    }).length,
    submitted: assignments.filter((a) => getAssignmentStatus(a) === 'submitted').length,
    graded: assignments.filter((a) => getAssignmentStatus(a) === 'graded').length,
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Mobile Navigation */}
      <MobileNav 
        role="student" 
        userName={user?.email}
      />
      
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 bg-white border-r border-gray-200 flex-col">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <BookOpen className="h-5 w-5 text-white" />
            </div>
            <span className="font-bold text-xl">AssignMate</span>
          </div>
        </div>

        <nav className="flex-1 p-4">
          <div className="space-y-1">
            <Link href="/student" className="flex items-center gap-3 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50">
              <Home className="h-5 w-5" />
              <span>Overview</span>
            </Link>
            <Link href="/student/assignments" className="flex items-center gap-3 px-3 py-2 rounded-lg bg-gray-100 text-gray-900">
              <FileText className="h-5 w-5" />
              <span className="font-medium">Assignments</span>
            </Link>
          </div>
        </nav>

        <div className="p-4 border-t border-gray-200">
          <Button variant="ghost" className="w-full justify-start">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden lg:pt-0 pt-14">
        {/* Top Navigation */}
        <header className="hidden lg:block bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-semibold">Dashboard / <span className="text-gray-500">Assignments</span></h1>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <User className="h-4 w-4" />
              <span>Student</span>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="max-w-7xl mx-auto space-y-4 sm:space-y-6">
            {/* Header */}
            <div>
              <h2 className="text-xl sm:text-2xl font-bold">Assignments</h2>
              <p className="text-sm sm:text-base text-gray-600 mt-1">Select your class to view assignments</p>
            </div>

            {/* Class Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Select Class</CardTitle>
                <CardDescription>Choose your branch and class to view assignments</CardDescription>
              </CardHeader>
              <CardContent>
                <BranchClassPicker
                  branchId={selectedBranch}
                  classId={selectedClass}
                  onBranchChange={(id) => {
                    setSelectedBranch(id)
                    setSelectedClass('')
                  }}
                  onClassChange={setSelectedClass}
                />
              </CardContent>
            </Card>

            {/* Stats - Only show when class is selected */}
            {selectedClass && (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between p-3 sm:p-4 pb-2">
                    <div className="w-8 sm:w-10 h-8 sm:h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                      <FileText className="h-4 sm:h-5 w-4 sm:w-5 text-gray-600" />
                    </div>
                    <span className="text-xs sm:text-sm text-blue-600 font-medium">All</span>
                  </CardHeader>
                  <CardContent className="p-3 sm:p-4 pt-0">
                    <div className="text-2xl sm:text-3xl font-bold">{stats.total}</div>
                    <p className="text-xs sm:text-sm text-gray-600 mt-1">Total Assignments</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between p-3 sm:p-4 pb-2">
                    <div className="w-8 sm:w-10 h-8 sm:h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                      <Clock className="h-4 sm:h-5 w-4 sm:w-5 text-amber-600" />
                    </div>
                    <span className="text-xs sm:text-sm text-amber-600 font-medium">{stats.pending}</span>
                  </CardHeader>
                  <CardContent className="p-3 sm:p-4 pt-0">
                    <div className="text-2xl sm:text-3xl font-bold">{stats.pending}</div>
                    <p className="text-xs sm:text-sm text-gray-600 mt-1">Pending</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between p-3 sm:p-4 pb-2">
                    <div className="w-8 sm:w-10 h-8 sm:h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                      <FileText className="h-4 sm:h-5 w-4 sm:w-5 text-blue-600" />
                    </div>
                    <span className="text-xs sm:text-sm text-blue-600 font-medium">{stats.submitted}</span>
                  </CardHeader>
                  <CardContent className="p-3 sm:p-4 pt-0">
                    <div className="text-2xl sm:text-3xl font-bold">{stats.submitted}</div>
                    <p className="text-xs sm:text-sm text-gray-600 mt-1">Submitted</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between p-3 sm:p-4 pb-2">
                    <div className="w-8 sm:w-10 h-8 sm:h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                      <CheckCircle2 className="h-4 sm:h-5 w-4 sm:w-5 text-green-600" />
                    </div>
                    <span className="text-xs sm:text-sm text-green-600 font-medium">{stats.graded}</span>
                  </CardHeader>
                  <CardContent className="p-3 sm:p-4 pt-0">
                    <div className="text-2xl sm:text-3xl font-bold">{stats.graded}</div>
                    <p className="text-xs sm:text-sm text-gray-600 mt-1">Graded</p>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Assignments Table - Only show when class is selected */}
            {selectedClass && (
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Assignments List</CardTitle>
                    <CardDescription>View and manage your assignments</CardDescription>
                  </div>
                  {loading && <RefreshCw className="h-4 w-4 animate-spin text-gray-400" />}
                </CardHeader>
                <CardContent>
                  <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value)}>
                    <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
                      <TabsTrigger value="all" className="text-xs sm:text-sm">All ({stats.total})</TabsTrigger>
                      <TabsTrigger value="pending" className="text-xs sm:text-sm">Pending ({stats.pending})</TabsTrigger>
                      <TabsTrigger value="submitted" className="text-xs sm:text-sm">Submitted ({stats.submitted})</TabsTrigger>
                      <TabsTrigger value="graded" className="text-xs sm:text-sm">Graded ({stats.graded})</TabsTrigger>
                    </TabsList>

                    <TabsContent value={activeTab} className="mt-4">
                      {loading ? (
                        <div className="text-center py-12">
                          <RefreshCw className="h-8 w-8 mx-auto text-gray-400 mb-3 animate-spin" />
                          <p className="text-gray-600">Loading assignments...</p>
                        </div>
                      ) : filteredAssignments.length === 0 ? (
                        <div className="text-center py-12">
                          <BookOpen className="h-12 w-12 mx-auto text-gray-400 mb-3" />
                          <p className="text-gray-600">
                            {activeTab === 'pending' && 'No pending assignments'}
                            {activeTab === 'submitted' && 'No submitted assignments'}
                            {activeTab === 'graded' && 'No graded assignments yet'}
                            {activeTab === 'all' && (assignments.length === 0 ? 'No assignments in this class yet' : 'No assignments match the current filter')}
                          </p>
                          <p className="text-sm text-gray-500 mt-1">Check back later for updates</p>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {filteredAssignments.map((assignment) => {
                            const status = getAssignmentStatus(assignment)
                            const dueDate = new Date(assignment.due_at)
                            return (
                              <Link key={assignment.id} href={`/student/assignments/${assignment.id}`}>
                                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 sm:p-4 border rounded-lg hover:bg-gray-50 hover:shadow-sm transition-all">
                                  <div className="flex items-start sm:items-center gap-3 sm:gap-4 mb-3 sm:mb-0 flex-1">
                                    <div className="w-8 sm:w-10 h-8 sm:h-10 rounded-lg flex items-center justify-center flex-shrink-0">
                                      {getStatusIcon(status)}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <h4 className="font-medium text-sm sm:text-base text-gray-900 truncate">{assignment.title}</h4>
                                      <p className="text-xs sm:text-sm text-gray-600">{assignment.class.name}</p>
                                      <p className="text-xs text-gray-500">{assignment.class.branch.name}</p>
                                      {assignment.description && (
                                        <p className="text-xs text-gray-500 mt-1 line-clamp-2">{assignment.description}</p>
                                      )}
                                    </div>
                                  </div>
                                  <div className="flex items-center justify-between sm:justify-end gap-3 sm:gap-6">
                                    <div className="text-left sm:text-right">
                                      <p className="text-xs sm:text-sm text-gray-700">Due: {formatDistanceToNow(dueDate, { addSuffix: true })}</p>
                                      <p className="text-xs text-gray-500">{dueDate.toLocaleDateString()}</p>
                                      {status === 'graded' && assignment.submissions?.[0]?.grade && (
                                        <p className="text-xs sm:text-sm font-semibold text-green-600 mt-1">Grade: {assignment.submissions[0].grade}</p>
                                      )}
                                      {status === 'submitted' && assignment.submissions?.[0]?.submitted_at && (
                                        <p className="text-xs sm:text-sm text-blue-600 mt-1">Submitted {formatDistanceToNow(new Date(assignment.submissions[0].submitted_at), { addSuffix: true })}</p>
                                      )}
                                    </div>
                                    <div className={`px-2 sm:px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(status)}`}>
                                      {status === 'overdue' ? 'Overdue' : status.charAt(0).toUpperCase() + status.slice(1)}
                                    </div>
                                  </div>
                                </div>
                              </Link>
                            )
                          })}
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            )}

            {/* Show message when no class is selected */}
            {!selectedClass && (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-12">
                    <BookOpen className="h-12 w-12 mx-auto text-gray-400 mb-3" />
                    <p className="text-gray-600 mb-2">Select a class to view assignments</p>
                    <p className="text-sm text-gray-500">Choose your branch and class from the dropdown above to get started</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
    </div>
  )
}

export default function AssignmentsPage() {
  return (
    <Suspense fallback={<div className="p-6">Loading...</div>}>
      <AssignmentsPageInner />
    </Suspense>
  )
}
