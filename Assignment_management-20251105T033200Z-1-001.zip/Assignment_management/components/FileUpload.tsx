'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Upload } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface FileUploadProps {
  assignmentId: string
  studentId: string
  onUploadComplete: () => void
}

export function FileUpload({ assignmentId, studentId, onUploadComplete }: FileUploadProps) {
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const allowedTypes = ['.pdf', '.png', '.jpg', '.jpeg', '.zip', '.txt']
    const fileExt = file.name.substring(file.name.lastIndexOf('.')).toLowerCase()
    
    if (!allowedTypes.includes(fileExt)) {
      setError('Invalid file type. Allowed: PDF, PNG, JPG, ZIP, TXT')
      return
    }

    if (file.size > 20 * 1024 * 1024) {
      setError('File size must be less than 20MB')
      return
    }

    setUploading(true)
    setError(null)

    try {
      const supabase = createClient()
      const fileName = `${studentId}-${Date.now()}-${file.name}`
      const filePath = `submissions/${assignmentId}/${fileName}`

      const { error: uploadError } = await supabase.storage
        .from('submissions')
        .upload(filePath, file)

      if (uploadError) throw uploadError

      const { error: dbError } = await supabase
        .from('submissions')
        .upsert({
          assignment_id: assignmentId,
          student_id: studentId,
          file_path: filePath,
          file_type: file.type,
        }, {
          onConflict: 'assignment_id,student_id'
        })

      if (dbError) throw dbError

      onUploadComplete()
    } catch (err: any) {
      setError(err.message || 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="space-y-2">
      <label htmlFor="file-upload" className="cursor-pointer">
        <div className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 transition-colors">
          <div className="text-center">
            <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
            <p className="text-sm text-gray-600">
              {uploading ? 'Uploading...' : 'Click to upload or drag and drop'}
            </p>
            <p className="text-xs text-gray-500">PDF, PNG, JPG, ZIP, TXT (max 20MB)</p>
          </div>
        </div>
        <input
          id="file-upload"
          type="file"
          className="hidden"
          accept=".pdf,.png,.jpg,.jpeg,.zip,.txt"
          onChange={handleFileChange}
          disabled={uploading}
        />
      </label>
      {error && <p className="text-red-500 text-sm">{error}</p>}
    </div>
  )
}
