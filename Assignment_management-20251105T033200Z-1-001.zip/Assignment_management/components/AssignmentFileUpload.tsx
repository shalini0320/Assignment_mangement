'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Upload, X } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface FilePreview {
  file: File
  id: string
}

interface AssignmentFileUploadProps {
  onFilesReady: (files: FilePreview[]) => void
}

export function AssignmentFileUpload({ onFilesReady }: AssignmentFileUploadProps) {
  const [files, setFiles] = useState<FilePreview[]>([])
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const allowedTypes = ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.png', '.jpg', '.jpeg', '.zip']
  const maxFileSize = 50 * 1024 * 1024 // 50MB

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = event.target.files
    if (!selectedFiles) return

    setError(null)
    const newFiles: FilePreview[] = []

    for (let i = 0; i < selectedFiles.length; i++) {
      const file = selectedFiles[i]
      const fileExt = file.name.substring(file.name.lastIndexOf('.')).toLowerCase()

      if (!allowedTypes.includes(fileExt)) {
        setError(`Invalid file type: ${fileExt}. Allowed: ${allowedTypes.join(', ')}`)
        return
      }

      if (file.size > maxFileSize) {
        setError(`File "${file.name}" is too large. Maximum size is 50MB`)
        return
      }

      newFiles.push({
        file,
        id: `${Date.now()}-${i}`,
      })
    }

    const updatedFiles = [...files, ...newFiles]
    setFiles(updatedFiles)
    onFilesReady(updatedFiles)
  }

  const removeFile = (id: string) => {
    const updatedFiles = files.filter(f => f.id !== id)
    setFiles(updatedFiles)
    onFilesReady(updatedFiles)
  }

  return (
    <div className="space-y-3">
      <label htmlFor="file-upload" className="cursor-pointer">
        <div className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 transition-colors bg-gray-50">
          <div className="text-center">
            <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
            <p className="text-sm text-gray-600">Click to upload or drag and drop</p>
            <p className="text-xs text-gray-500">PDF, DOC, XLS, PPT, Images, ZIP (max 50MB)</p>
          </div>
        </div>
        <input
          id="file-upload"
          type="file"
          className="hidden"
          accept={allowedTypes.join(',')}
          onChange={handleFileChange}
          multiple
          disabled={uploading}
        />
      </label>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded p-3">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      )}

      {files.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm font-medium text-gray-700">
            Selected Files ({files.length})
          </p>
          <div className="space-y-2">
            {files.map((file) => (
              <div
                key={file.id}
                className="flex items-center justify-between bg-gray-50 p-3 rounded-lg border border-gray-200"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {file.file.name}
                  </p>
                  <p className="text-xs text-gray-500">
                    {(file.file.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => removeFile(file.id)}
                  className="ml-2 text-red-500 hover:text-red-700"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
