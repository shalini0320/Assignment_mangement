'use client'

import { useState } from 'react'
import { Menu, X, Home, FileText, LogOut, Users, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import Image from 'next/image'
import { cn } from '@/lib/utils'

interface MobileNavProps {
  role: 'student' | 'teacher'
  userName?: string
  onLogout?: () => void
}

export function MobileNav({ role, userName, onLogout }: MobileNavProps) {
  const [isOpen, setIsOpen] = useState(false)

  const navigationItems = role === 'student' 
    ? [
        { href: '/student', icon: Home, label: 'Overview' },
        { href: '/student/assignments', icon: FileText, label: 'Assignments' },
      ]
    : [
        { href: '/teacher', icon: Home, label: 'Overview' },
        { href: '/teacher', icon: FileText, label: 'Assignments' },
        { href: '/teacher', icon: Users, label: 'Students' },
      ]

  return (
    <>
      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <Image
              src="/logo.png"
              width={80}
              height={80}
              alt="Logo"
              className="rounded-2xl"
            />
            <span className="font-bold text-xl">AssignMate</span>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      {isOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-black bg-opacity-50"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Mobile Sidebar */}
      <aside
        className={cn(
          "lg:hidden fixed top-0 left-0 z-50 h-full w-64 bg-white border-r border-gray-200 transform transition-transform duration-300",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex flex-col h-full">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Image
                  src="/logo.png"
                  width={80}
                  height={80}
                  alt="Logo"
                  className="rounded-2xl"
                />
                <span className="font-bold text-xl">AssignMate</span>
              </div>
              <Button
                variant="ghost"
                size="icon-sm"
                onClick={() => setIsOpen(false)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <nav className="flex-1 p-4">
            <div className="space-y-1">
              {navigationItems.map((item) => (
                <Link
                  key={`${item.href}-${item.label}`}
                  href={item.href}
                  onClick={() => setIsOpen(false)}
                  className="flex items-center gap-3 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50"
                >
                  <item.icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </Link>
              ))}
            </div>

            {role === 'teacher' && (
              <Link href="/teacher/assignments/new">
                <Button className="w-full mt-4 bg-blue-600 hover:bg-blue-700" onClick={() => setIsOpen(false)}>
                  <Plus className="h-4 w-4 mr-2" />
                  New Assignment
                </Button>
              </Link>
            )}
          </nav>

          {userName && (
            <div className="p-4 border-t border-gray-200">
              <p className="text-sm text-gray-600 mb-3 truncate">
                {userName}
              </p>
              {onLogout && (
                <Button variant="ghost" onClick={onLogout} className="w-full justify-start">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              )}
            </div>
          )}
        </div>
      </aside>
    </>
  )
}