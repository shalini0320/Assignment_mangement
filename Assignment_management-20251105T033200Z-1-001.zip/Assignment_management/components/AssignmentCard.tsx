import Link from 'next/link'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Calendar, Clock } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

interface AssignmentCardProps {
  assignment: {
    id: string
    title: string
    description?: string
    due_at: string
    class?: {
      name: string
      branch?: {
        name: string
      }
    }
    submissions?: Array<{
      grade?: string
      feedback?: string
    }>
  }
  role: 'student' | 'teacher'
}

export function AssignmentCard({ assignment, role }: AssignmentCardProps) {
  const dueDate = new Date(assignment.due_at)
  const isOverdue = dueDate < new Date()
  const hasSubmission = assignment.submissions && assignment.submissions.length > 0
  const isGraded = hasSubmission && assignment.submissions[0].grade

  const getStatusBadge = () => {
    if (role === 'teacher') return null
    
    if (isGraded) {
      return <Badge variant="default" className="bg-green-500">Graded</Badge>
    }
    if (hasSubmission) {
      return <Badge variant="default" className="bg-blue-500">Submitted</Badge>
    }
    if (isOverdue) {
      return <Badge variant="destructive">Overdue</Badge>
    }
    return <Badge variant="outline" className="border-amber-500 text-amber-500">Not Submitted</Badge>
  }

  return (
    <Link href={role === 'student' ? `/student/assignments/${assignment.id}` : `/teacher/assignments/${assignment.id}`}>
      <Card className="hover:shadow-lg transition-shadow cursor-pointer">
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <CardTitle className="text-lg">{assignment.title}</CardTitle>
            {getStatusBadge()}
          </div>
        </CardHeader>
        <CardContent className="pb-2">
          {assignment.description && (
            <p className="text-sm text-gray-600 line-clamp-2 mb-3">{assignment.description}</p>
          )}
          {assignment.class && (
            <p className="text-sm text-gray-500">
              {assignment.class.branch?.name} - {assignment.class.name}
            </p>
          )}
        </CardContent>
        <CardFooter className="flex items-center text-sm text-gray-500 pt-3 border-t">
          <Calendar className="h-4 w-4 mr-1" />
          <span className={isOverdue ? 'text-red-500' : ''}>
            Due {formatDistanceToNow(dueDate, { addSuffix: true })}
          </span>
        </CardFooter>
      </Card>
    </Link>
  )
}
