'use client'

import { useEffect, useState } from 'react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Plus } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

interface BranchClassPickerProps {
  branchId: string
  classId: string
  onBranchChange: (id: string) => void
  onClassChange: (id: string) => void
}

interface Branch {
  id: string
  name: string
}

interface Class {
  id: string
  name: string
}

export function BranchClassPicker({ branchId, classId, onBranchChange, onClassChange }: BranchClassPickerProps) {
  const [branches, setBranches] = useState<Branch[]>([])
  const [classes, setClasses] = useState<Class[]>([])
  const [loading, setLoading] = useState(true)
  const [newBranchName, setNewBranchName] = useState('')
  const [newClassName, setNewClassName] = useState('')
  const [branchDialogOpen, setBranchDialogOpen] = useState(false)
  const [classDialogOpen, setClassDialogOpen] = useState(false)
  const [savingBranch, setSavingBranch] = useState(false)
  const [savingClass, setSavingClass] = useState(false)
  const [error, setError] = useState('')
  const [userRole, setUserRole] = useState<string | null>(null)

  useEffect(() => {
    const checkUserRole = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .single()
        setUserRole(profile?.role || null)
      }
    }
    checkUserRole()
  }, [])

  useEffect(() => {
    const fetchBranches = async () => {
      const supabase = createClient()
      const { data } = await supabase.from('branches').select('id, name').order('name')
      setBranches(data || [])
      setLoading(false)
    }
    fetchBranches()
  }, [])

  useEffect(() => {
    if (!branchId) {
      setClasses([])
      return
    }

    const fetchClasses = async () => {
      const supabase = createClient()
      const { data } = await supabase
        .from('classes')
        .select('id, name')
        .eq('branch_id', branchId)
        .order('name')
      setClasses(data || [])
    }
    fetchClasses()
  }, [branchId])

  const handleAddBranch = async () => {
    if (!newBranchName.trim()) {
      setError('Branch name cannot be empty')
      return
    }

    setSavingBranch(true)
    setError('')

    try {
      const supabase = createClient()
      const { data, error: insertError } = await supabase
        .from('branches')
        .insert({ name: newBranchName })
        .select()

      if (insertError) throw insertError

      const newBranch = data?.[0]
      if (newBranch) {
        setBranches([...branches, newBranch])
        onBranchChange(newBranch.id)
        setNewBranchName('')
        setBranchDialogOpen(false)
      }
    } catch (err: any) {
      setError(err.message || 'Failed to create branch')
    } finally {
      setSavingBranch(false)
    }
  }

  const handleAddClass = async () => {
    if (!newClassName.trim()) {
      setError('Class name cannot be empty')
      return
    }

    setSavingClass(true)
    setError('')

    try {
      const supabase = createClient()
      const { data, error: insertError } = await supabase
        .from('classes')
        .insert({ name: newClassName, branch_id: branchId })
        .select()

      if (insertError) throw insertError

      const newClass = data?.[0]
      if (newClass) {
        setClasses([...classes, newClass])
        onClassChange(newClass.id)
        setNewClassName('')
        setClassDialogOpen(false)
      }
    } catch (err: any) {
      setError(err.message || 'Failed to create class')
    } finally {
      setSavingClass(false)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <div className="flex items-center justify-between mb-2">
          <Label htmlFor="branch">Branch</Label>
          {userRole === 'teacher' && (
            <Dialog open={branchDialogOpen} onOpenChange={setBranchDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="h-6 px-2">
                  <Plus className="h-3 w-3 mr-1" />
                  Add
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Branch</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="Enter branch name"
                    value={newBranchName}
                    onChange={(e) => setNewBranchName(e.target.value)}
                    disabled={savingBranch}
                  />
                  {error && <p className="text-red-500 text-sm">{error}</p>}
                  <Button
                    onClick={handleAddBranch}
                    disabled={savingBranch || !newBranchName.trim()}
                    className="w-full"
                  >
                    {savingBranch ? 'Creating...' : 'Create Branch'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
        <Select value={branchId} onValueChange={onBranchChange} disabled={loading}>
          <SelectTrigger id="branch" className="mt-1">
            <SelectValue placeholder="Select Branch" />
          </SelectTrigger>
          <SelectContent>
            {branches.map((branch) => (
              <SelectItem key={branch.id} value={branch.id}>
                {branch.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <div className="flex items-center justify-between mb-2">
          <Label htmlFor="class">Class</Label>
          {userRole === 'teacher' && (
            <Dialog open={classDialogOpen} onOpenChange={setClassDialogOpen}>
              <DialogTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-2"
                  disabled={!branchId}
                >
                  <Plus className="h-3 w-3 mr-1" />
                  Add
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Class</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="Enter class name"
                    value={newClassName}
                    onChange={(e) => setNewClassName(e.target.value)}
                    disabled={savingClass}
                  />
                  {error && <p className="text-red-500 text-sm">{error}</p>}
                  <Button
                    onClick={handleAddClass}
                    disabled={savingClass || !newClassName.trim()}
                    className="w-full"
                  >
                    {savingClass ? 'Creating...' : 'Create Class'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
        <Select value={classId} onValueChange={onClassChange} disabled={!branchId || classes.length === 0}>
          <SelectTrigger id="class" className="mt-1">
            <SelectValue placeholder="Select Class" />
          </SelectTrigger>
          <SelectContent>
            {classes.map((cls) => (
              <SelectItem key={cls.id} value={cls.id}>
                {cls.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  )
}
