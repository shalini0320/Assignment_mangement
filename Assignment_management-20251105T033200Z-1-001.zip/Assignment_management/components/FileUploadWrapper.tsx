'use client'

import { FileUpload } from '@/components/FileUpload'

interface FileUploadWrapperProps {
  assignmentId: string
  studentId: string
}

export function FileUploadWrapper({ assignmentId, studentId }: FileUploadWrapperProps) {
  return (
    <FileUpload
      assignmentId={assignmentId}
      studentId={studentId}
      onUploadComplete={() => window.location.reload()}
    />
  )
}
