'use client'

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

interface RoleSelectProps {
  value: string
  onChange: (value: string) => void
  error?: string
}

export function RoleSelect({ value, onChange, error }: RoleSelectProps) {
  return (
    <div className="w-full">
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="w-full bg-[#1a1d2e] border-[#2a2d3e] text-white">
          <SelectValue placeholder="-- Select Role --" />
        </SelectTrigger>
        <SelectContent className="bg-[#1a1d2e] border-[#2a2d3e]">
          <SelectItem value="student" className="text-white hover:bg-[#2a2d3e]">
            Student
          </SelectItem>
          <SelectItem value="teacher" className="text-white hover:bg-[#2a2d3e]">
            Teacher
          </SelectItem>
        </SelectContent>
      </Select>
      {error && <p className="text-red-400 text-sm mt-1">{error}</p>}
    </div>
  )
}
