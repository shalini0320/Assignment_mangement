import { z } from 'zod'

export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  role: z.enum(['student', 'teacher'], {
    required_error: 'Please select a role',
  }),
})

export const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  fullName: z.string().min(2, 'Full name must be at least 2 characters'),
  role: z.enum(['student', 'teacher'], {
    required_error: 'Please select a role',
  }),
})

export const createAssignmentSchema = z.object({
  classId: z.string().uuid('Invalid class ID'),
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  dueAt: z.string().refine((date) => new Date(date) > new Date(), {
    message: 'Due date must be in the future',
  }),
})

export const submitWorkSchema = z.object({
  assignmentId: z.string().uuid('Invalid assignment ID'),
  file: z.any().refine((file) => file !== null, 'File is required'),
})

export const gradeSubmissionSchema = z.object({
  submissionId: z.string().uuid('Invalid submission ID'),
  grade: z.string().min(1, 'Grade is required'),
  feedback: z.string().optional(),
})

export type LoginInput = z.infer<typeof loginSchema>
export type RegisterInput = z.infer<typeof registerSchema>
export type CreateAssignmentInput = z.infer<typeof createAssignmentSchema>
export type SubmitWorkInput = z.infer<typeof submitWorkSchema>
export type GradeSubmissionInput = z.infer<typeof gradeSubmissionSchema>
