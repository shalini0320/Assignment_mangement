# AssignMate

A complete assignment management system built with Next.js 14+ and Supabase. Features role-based authentication for **Students** and **Teachers** with full assignment lifecycle management.

## Features

### For Teachers
- ✅ Create assignments by branch & class
- ✅ View all submissions
- ✅ Download student files
- ✅ Grade assignments with feedback
- ✅ Filter assignments by branch/class

### For Students
- ✅ View assigned work
- ✅ Upload submissions (PDF/PNG/JPG/ZIP/TXT)
- ✅ Replace submissions before grading
- ✅ View grades & feedback
- ✅ Track assignment status

## Tech Stack

- **Framework:** Next.js 14+ (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS + shadcn/ui
- **Database:** Supabase (PostgreSQL)
- **Auth:** Supabase Auth (Email + Password)
- **Storage:** Supabase Storage
- **Validation:** Zod

## Database Design

- `profiles` - User profiles with roles (student/teacher)
- `branches` - Academic branches (e.g., CS, IT)
- `classes` - Classes within branches
- `enrollments` - Student-class relationships
- `class_teachers` - Teacher-class assignments
- `assignments` - Created by teachers
- `submissions` - Student work with grades/feedback

**Important:** All tables have RLS **disabled** for local/learning purposes only.

## Setup Instructions

### 1. Prerequisites

- Node.js 18+ installed
- A Supabase account (free tier works)
- Git

### 2. Install Dependencies

```bash
npm install
```

### 3. Supabase Setup

#### A. Create Supabase Project
1. Go to [supabase.com](https://supabase.com)
2. Create a new project
3. Wait for database to provision

#### B. Run Database Schema
1. Open Supabase SQL Editor
2. Copy contents of `supabase-setup.sql`
3. Execute the SQL
4. Verify all tables are created

#### C. Configure Storage
1. Go to **Storage** in Supabase dashboard
2. Click **New bucket**
3. Name: `submissions`
4. Make it **Public**
5. Configure allowed MIME types in bucket settings:
   - `application/pdf`
   - `image/png`
   - `image/jpeg`
   - `application/zip`
   - `text/plain`
6. Set max file size: 20MB

### 4. Environment Variables

Create `.env.local` in project root:

```bash
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

Get these from: Supabase Dashboard → Project Settings → API

### 5. Run Development Server

```bash
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000)

## Usage

### Creating Demo Accounts

1. **Register Teacher:**
   - Go to `/register`
   - Select "Teacher" role
   - Email: `teacher@example.com`
   - Password: `password123`

2. **Register Student:**
   - Go to `/register`
   - Select "Student" role
   - Email: `student@example.com`
   - Password: `password123`

### Setting Up Classes

After creating accounts, run these SQL commands in Supabase (replace UUIDs with actual user IDs from `auth.users`):

```sql
-- Get user IDs
SELECT id, email FROM auth.users;

-- Enroll student in CS-1A
INSERT INTO enrollments (class_id, student_id) VALUES 
  ('33333333-3333-3333-3333-333333333333', '<STUDENT_USER_ID>');

-- Assign teacher to CS-1A
INSERT INTO class_teachers (class_id, teacher_id) VALUES 
  ('33333333-3333-3333-3333-333333333333', '<TEACHER_USER_ID>');
```

### Workflow

1. **Teacher** logs in → Creates assignment for a class
2. **Student** logs in → Sees assignment → Uploads file
3. **Teacher** views submissions → Downloads file → Grades with feedback
4. **Student** sees grade and feedback

## Project Structure

```
v0-demo/
├── app/
│   ├── login/page.tsx           # Login (dark theme)
│   ├── register/page.tsx        # Registration
│   ├── student/
│   │   ├── page.tsx             # Student dashboard
│   │   └── assignments/[id]/    # Assignment detail + upload
│   ├── teacher/
│   │   ├── page.tsx             # Teacher dashboard
│   │   ├── assignments/
│   │   │   ├── new/             # Create assignment
│   │   │   └── [id]/            # View submissions & grade
│   └── globals.css
├── components/
│   ├── RoleSelect.tsx           # Role dropdown
│   ├── RoleGate.tsx             # Server-side role check
│   ├── FileUpload.tsx           # File upload component
│   ├── AssignmentCard.tsx       # Assignment display
│   └── BranchClassPicker.tsx    # Branch/class selector
├── lib/
│   ├── supabase/
│   │   ├── client.ts            # Client-side Supabase
│   │   └── server.ts            # Server-side Supabase
│   └── validators.ts            # Zod schemas
├── supabase-setup.sql           # Complete DB schema
└── README.md
```

## Security Note

⚠️ **This project has RLS disabled on all tables.** This is intentional for local development and learning purposes only.

**DO NOT deploy to production without:**
- Enabling RLS on all tables
- Adding proper security policies
- Validating user permissions
- Securing storage bucket policies

## Key Design Decisions

### No RLS
All tables have `ALTER TABLE ... DISABLE ROW LEVEL SECURITY` for simplicity. Perfect for learning, unsafe for production.

### Role Validation
- Role is stored in `profiles` table (source of truth)
- Login validates role matches dropdown selection
- `RoleGate` component enforces server-side access control

### File Storage
- Public bucket for simplicity
- Files organized: `submissions/{assignmentId}/{userId}-{timestamp}-{filename}`
- Supports: PDF, PNG, JPG, ZIP, TXT (max 20MB)

### UI Design
- Login matches dark theme (#0f1115 bg, #4db2ff blue accent, gradient button)
- Dashboard uses existing template style (white cards, clean tables)
- Responsive design with Tailwind

## Troubleshooting

### "Invalid login credentials"
- Verify email/password are correct
- Check role matches account type in database

### "File upload failed"
- Verify storage bucket "submissions" exists and is public
- Check file size (max 20MB)
- Verify allowed file types

### "Assignment not found"
- Student must be enrolled in class
- Check `enrollments` table in Supabase

### No assignments showing
- Teacher must be assigned to class via `class_teachers`
- Student must be enrolled via `enrollments`

## Development Commands

```bash
npm run dev      # Start dev server
npm run build    # Production build
npm run start    # Start production server
npm run lint     # Run ESLint
```

## License

MIT - Free for learning and personal use

## Support

For issues, check:
1. Supabase logs (Dashboard → Logs)
2. Browser console
3. Network tab for API errors

---

**Built for learning Supabase + Next.js 14 App Router** 🚀
